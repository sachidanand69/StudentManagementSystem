package hibernate_image.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hibernate_image.dao.StudentDao;
import hibernate_image.dto.Student;
import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServlet;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class StudentController extends HttpServlet{
 
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws javax.servlet.ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=req.getParameter("firstname");
		String lname=req.getParameter("lastname");
		long phone=Long.parseLong(req.getParameter("phone"));
		String email=req.getParameter("email");
		double Gmarks=Double.parseDouble(req.getParameter("gettingmarks"));
		double Tmarks=Double.parseDouble(req.getParameter("totalmarks"));
		double per=(Gmarks/Tmarks)*100;
		
		
		try {
			Student student=new Student();
			student.setFname(fname);
			student.setLname(lname);
			student.setPhone(phone);
			student.setEmail(email);
			student.setGmarks(Gmarks);
			student.setTmarks(Tmarks);
			student.setPercentage(per);
			
			HttpSession session=req.getSession();
			session.setAttribute("email",email);
			
		       StudentDao dao=new StudentDao();
		       dao.saveStudent(student);
		       req.setAttribute("student", student);
		       
		       RequestDispatcher dispatcher=req.getRequestDispatcher("home.jsp");
		       dispatcher.forward(req, resp);
		       
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
